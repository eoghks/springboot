package com.example.demo.repository;

import com.example.demo.controller.BookForm;
import com.example.demo.domain.Book;

import java.util.List;

public interface BookRepository {
    List<Book> findAll();
    Book save(Book book);
    List<Book> findCond(BookForm form);
}
