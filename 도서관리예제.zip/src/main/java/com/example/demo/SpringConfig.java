package com.example.demo;

import com.example.demo.repository.JdbcBookRepository;
import com.example.demo.service.BookService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.example.demo.repository.BookRepository;


import javax.sql.DataSource;

@Configuration
public class SpringConfig {
    private final DataSource dataSource;
    public SpringConfig(DataSource datasource){
        this.dataSource=datasource;
    }
    @Bean
    public BookService bookService(){return new BookService(bookRepository());}

    private BookRepository bookRepository() {
        return new JdbcBookRepository(dataSource);
    }
}
